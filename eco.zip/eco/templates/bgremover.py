import cv2
import numpy as np
from sklearn.cluster import KMeans

def find_dominant_colors(image, num_colors=3):
    # Reshape the image to be a list of pixels
    pixels = image.reshape(-1, 3)
    
    # Use KMeans to fit the pixels and find dominant colors
    kmeans = KMeans(n_clusters=num_colors)
    kmeans.fit(pixels)
    
    # Get the RGB values of the cluster centers (colors)
    colors = kmeans.cluster_centers_.astype(int)
    
    return colors

def suppress_background(image, dominant_colors):
    # Convert image to RGB (OpenCV uses BGR by default)
    image_rgb = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
    
    # Flatten image for easier manipulation
    pixels = image_rgb.reshape(-1, 3)
    
    # Compute distances to each dominant color
    distances = np.linalg.norm(pixels[:, np.newaxis] - dominant_colors, axis=-1)
    
    # Find indices of closest color to each pixel
    closest_color_index = np.argmin(distances, axis=1)
    
    # Reshape indices to match original image shape
    mask = closest_color_index.reshape(image.shape[:-1])
    
    # Create a mask where 1 is for the item area and 0 is for background
    item_mask = np.where(mask == np.argmax(np.bincount(mask.flat)), 255, 0).astype(np.uint8)
    
    # Invert the mask to get background suppression mask
    background_mask = cv2.bitwise_not(item_mask)
    
    # Create a white background image
    white_background = np.ones_like(image) * 255
    
    # Apply the background suppression mask
    result = cv2.bitwise_or(cv2.bitwise_and(image, image, mask=item_mask), 
                            cv2.bitwise_and(white_background, white_background, mask=background_mask))
    
    return result

def process_and_display_single_image(image_path):
    # Read the original image
    original_image = cv2.imread(image_path)
    if original_image is None:
        print(f"Could not read image {image_path}")
        return
    
    # Find dominant colors in the image (can adjust number of colors as needed)
    dominant_colors = find_dominant_colors(original_image)
    
    # Suppress the background based on dominant colors
    result = suppress_background(original_image, dominant_colors)
    
    if result is not None:
        # Display the original image
        cv2.imshow('Original Image', original_image)
        # Display the image with the background suppressed
        cv2.imshow('Background Suppressed', result)
        cv2.waitKey(0)  # Wait for a key press to close the window
        cv2.destroyAllWindows()  # Close the window after the key press

# Example usage:
image_path = 'C:/Users/Jahnavi Undavalli/OneDrive/Desktop/abhi/eco/eco/static/image/product/dresses/60451.jpg'
process_and_display_single_image(image_path)
